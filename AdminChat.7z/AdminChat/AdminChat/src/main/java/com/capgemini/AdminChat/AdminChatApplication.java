package com.capgemini.AdminChat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdminChatApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdminChatApplication.class, args);
	}
}
