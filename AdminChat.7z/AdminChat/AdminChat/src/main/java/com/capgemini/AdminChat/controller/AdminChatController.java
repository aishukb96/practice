package com.capgemini.AdminChat.controller;

import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
import org.springframework.web.servlet.view.JstlView;

import com.capgemini.AdminChat.model.Customer;
import com.capgemini.AdminChat.model.Merchant;

@Controller
public class AdminChatController {
	

	/*@Bean
	public InternalResourceViewResolver getViewResolver() {
		InternalResourceViewResolver viewResolver=
				new InternalResourceViewResolver();
		viewResolver.setViewClass(JstlView.class);
		viewResolver.setPrefix("/WEB-INF/views/");
		viewResolver.setSuffix(".jsp");
		return viewResolver;
	}*/
	
	@RequestMapping("/chat")
	public String getActiveCustomersMerchantsList(ModelMap map) {
		final String uri="http://localhost:8085/api/v1/";
		RestTemplate restTemplate=new RestTemplate();
		Customer[] customers= restTemplate.getForObject(uri, Customer[].class);
		map.put("customers",customers);
		
		final String url="http://localhost:8085/api/v1/merchant/";
		Merchant[] merchants=restTemplate.getForObject(url, Merchant[].class);
		map.put("merchants", merchants);
		return "CustMerchActiveForm";
	}
	
	@GetMapping("/merchant/{mname}")
	public String openMerchantChat(@PathVariable("mname")String mname,Model model)
	{
		String username=mname;
		 model.addAttribute("username", username);
		 
	        return "MerchantChat";
	}
	
	@GetMapping("/customer/{cname}")
	public String openCustomerChat(@PathVariable("cname")String cname,Model model)
	{
		String username=cname;
		 model.addAttribute("username", username);
		 
	        return "CustomerChat";
	}

}
