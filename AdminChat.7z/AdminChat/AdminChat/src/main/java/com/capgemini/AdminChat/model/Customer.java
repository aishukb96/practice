package com.capgemini.AdminChat.model;

public class Customer {

private int custId;
private String cname;
private boolean cisactive;
public String getCname() {
	return cname;
}
public void setCname(String cname) {
	this.cname = cname;
}
public boolean isCisactive() {
	return cisactive;
}
public void setCisactive(boolean cisactive) {
	this.cisactive = cisactive;
}
public Customer(String cname, boolean cisactive) {
	super();
	this.cname = cname;
	this.cisactive = cisactive;
}
public Customer() {
	super();
}
public int getCustId() {
	return custId;
}
public void setCustId(int custId) {
	this.custId = custId;
}


}
