package com.capgemini.AdminChatRest.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.web.socket.config.annotation.EnableWebSocketMessageBroker;
import org.springframework.web.socket.config.annotation.StompEndpointRegistry;
import org.springframework.web.socket.config.annotation.WebSocketMessageBrokerConfigurer;

import com.capgemini.AdminChatRest.interceptor.HttpHandshakeInterceptor;

 
@Configuration //It indicates that it is a Spring configuration class.
@EnableWebSocketMessageBroker // It enables WebSocket message handling, backed by a message broker.
//Here we are using STOMP as a message broker.
public class WebSocketConfig implements WebSocketMessageBrokerConfigurer {
     
    @Autowired
    private HttpHandshakeInterceptor handshakeInterceptor;
 
    /*enables STOMP support and registers stomp endoints at "/ws" 
    sockJs purpose: whenever the websocket connection is disconnected or the websocket connection can not be established,
    then the connection will be downgraded to HTTP and the communication between client and server can still continue.*/
    @Override
    public void registerStompEndpoints(StompEndpointRegistry registry) {
        registry.addEndpoint("/ws").withSockJS().setInterceptors(handshakeInterceptor);
    }
 
    // enables a simple memory-based message broker to carry the messages back to the 
    //client on destinations prefixed with "/app" and "/topic"
    @Override
    public void configureMessageBroker(MessageBrokerRegistry registry) {
        registry.setApplicationDestinationPrefixes("/app");
        registry.enableSimpleBroker("/topic");
    }
 
}