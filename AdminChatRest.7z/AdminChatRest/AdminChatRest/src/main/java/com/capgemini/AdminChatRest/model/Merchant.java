package com.capgemini.AdminChatRest.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Merchant {
@Id
@GeneratedValue
private int merchantId;	
private String mname;
private boolean isactive;
public String getMname() {
	return mname;
}
public void setMname(String mname) {
	this.mname = mname;
}
public boolean isIsactive() {
	return isactive;
}
public void setIsactive(boolean isactive) {
	this.isactive = isactive;
}
public Merchant(String mname, boolean isactive) {
	super();
	this.mname = mname;
	this.isactive = isactive;
}
public Merchant() {
	super();
}
public int getMerchantId() {
	return merchantId;
}
public void setMerchantId(int merchantId) {
	this.merchantId = merchantId;
}


}
