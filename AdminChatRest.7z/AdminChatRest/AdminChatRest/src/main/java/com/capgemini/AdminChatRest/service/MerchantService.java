package com.capgemini.AdminChatRest.service;

import java.util.List;

import com.capgemini.AdminChatRest.model.Merchant;

public interface MerchantService {
	public List<Merchant> getAll();

}
