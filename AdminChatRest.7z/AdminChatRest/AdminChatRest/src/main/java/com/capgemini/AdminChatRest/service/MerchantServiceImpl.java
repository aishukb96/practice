package com.capgemini.AdminChatRest.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.AdminChatRest.dao.MerchantDao;
import com.capgemini.AdminChatRest.model.Merchant;

@Service("merchantService")
public class MerchantServiceImpl implements MerchantService{

	@Autowired
	private MerchantDao merchantDao;
	
	@Override
	public List<Merchant> getAll() {
		// TODO Auto-generated method stub
		return merchantDao.findByisactive(true);
	}

}
