package org.cap.demo;

import org.springframework.context.support.AbstractApplicationContext;
//import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class TestClass {
public static void main(String[] args)
{
	//AbstractApplicationContext context=new ClassPathXmlApplicationContext("demoBeans.xml");
	AbstractApplicationContext context=new FileSystemXmlApplicationContext("D:\\Users\\abaladha\\Desktop\\demoBeans.xml");
	Employee employee=(Employee)context.getBean("employee1");
	Address address=(Address)context.getBean("address1");
	System.out.println(employee);
	System.out.println(address);
	
	context.registerShutdownHook();
}
}
