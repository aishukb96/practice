package org.cap.demo;

import org.springframework.context.annotation.Bean;

public class JavaConfig {
@Bean
public Employee getEmpBean()
{
	Employee emp=new Employee();
	emp.setAge(22);
	emp.setEmployeeId(100);
	emp.setEmployeeName("Aishwarya");
	emp.setSalary(20000);
	return emp;
}
}
