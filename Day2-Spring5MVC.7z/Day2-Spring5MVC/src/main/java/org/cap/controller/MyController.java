package org.cap.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MyController {
	
@RequestMapping("/hello") //all servlet url should have slash.
public ModelAndView sayHello()
{
	String message="hello World!";
	return new ModelAndView("helloPage","msg",message); //page to be navigated next.
}
}
