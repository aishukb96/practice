package org.cap.demo;

import java.util.List;
import java.util.Map;
import java.util.Properties;

public class CollectionDemo {
private List<String> names;
private List<Address> addresses;
private List<String> fruits;
private Map<Integer,String> map;
private Properties myprops;
public Properties getMyprops() {
	return myprops;
}

public void setMyprops(Properties myprops) {
	this.myprops = myprops;
}

public Map<Integer, String> getMap() {
	return map;
}

public void setMap(Map<Integer, String> map) {
	this.map = map;
}

public List<String> getFruits() {
	return fruits;
}

public void setFruits(List<String> fruits) {
	this.fruits = fruits;
}

public List<Address> getAddresses() {
	return addresses;
}

public void setAddresses(List<Address> addresses) {
	this.addresses = addresses;
}

public List<String> getNames() {
	return names;
}

public void setNames(List<String> names) {
	this.names = names;
}

}
