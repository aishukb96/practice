package org.cap.demo;

public class Fruits {
private String fruitName;

public String getFruitName() {
	return fruitName;
}

public void setFruitName(String fruitName) {
	this.fruitName = fruitName;
}

}
