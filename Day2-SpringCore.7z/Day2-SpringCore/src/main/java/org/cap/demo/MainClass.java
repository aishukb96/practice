package org.cap.demo;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
AbstractApplicationContext ctx=new ClassPathXmlApplicationContext("myBeans.xml");
CollectionDemo demo=(CollectionDemo)ctx.getBean("collDemo");
System.out.println(demo.getAddresses());
System.out.println(demo.getNames());
System.out.println(demo.getFruits());
System.out.println(demo.getMap());
System.out.println(demo.getMyprops());
ctx.close();
	}

}
