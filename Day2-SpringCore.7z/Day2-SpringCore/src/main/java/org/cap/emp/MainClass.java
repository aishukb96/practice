package org.cap.emp;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
AbstractApplicationContext context=new ClassPathXmlApplicationContext("DemoBeans.xml");
Employee employee=(Employee) context.getBean("employee");
System.out.println(employee);
context.registerShutdownHook();
	}

}
