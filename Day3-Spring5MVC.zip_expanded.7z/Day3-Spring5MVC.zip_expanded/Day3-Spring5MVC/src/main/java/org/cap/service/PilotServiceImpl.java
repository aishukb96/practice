package org.cap.service;

import org.cap.dao.PilotDao;
import org.cap.model.Pilot;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("pilotService")
public class PilotServiceImpl implements PilotService{
	
	@Autowired
	private PilotDao pilotDao;

	@Override
	public void save(Pilot pilot) {
		//Your business logic goes here
		pilotDao.save(pilot);
	}

}
