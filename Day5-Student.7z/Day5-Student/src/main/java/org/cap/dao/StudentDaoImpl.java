package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.cap.model.Student;
import org.springframework.stereotype.Repository;
@Repository("studentDao") //interacts with db
@Transactional
public class StudentDaoImpl implements StudentDao{

	@PersistenceContext
	private EntityManager entityManager;
	

	@Override
	public List<Student> getAll() {
		// TODO Auto-generated method stub
		List<Student> students=entityManager.createQuery("from Student").getResultList();
		return students;
	}


	@Override
	public Student findStudent(Integer studentId) {
		Student student= entityManager.find(Student.class, studentId);
		return student;
	}

	@Override
	public void updateStudent(Student student) {
		Student student1=entityManager.find(Student.class, student.getStudId());
		if(student1==null)
			entityManager.persist(student);
		else
			entityManager.merge(student);
	}

}
