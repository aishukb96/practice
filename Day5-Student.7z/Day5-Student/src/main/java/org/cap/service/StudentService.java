package org.cap.service;

import java.util.List;

import org.cap.model.Student;

public interface StudentService {
	
	public List<Student> getAll();
	public Student findStudent(Integer studId);
	public void updateStudent(Student student1);

}
