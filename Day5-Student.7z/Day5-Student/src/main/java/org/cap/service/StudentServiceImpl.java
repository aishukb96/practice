package org.cap.service;

import java.util.List;

import org.cap.dao.StudentDao;
import org.cap.model.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("studentService")
public class StudentServiceImpl implements StudentService{

	@Autowired
	private StudentDao studentDao;
	
	@Override
	public List<Student> getAll() {
		// TODO Auto-generated method stub
		return studentDao.getAll();
	}

	

	@Override
	public void updateStudent(Student student) {
		// TODO Auto-generated method stub
		studentDao.updateStudent(student);
	}

	@Override
	public Student findStudent(Integer studId) {
		// TODO Auto-generated method stub
		return studentDao.findStudent(studId);
	}



}
