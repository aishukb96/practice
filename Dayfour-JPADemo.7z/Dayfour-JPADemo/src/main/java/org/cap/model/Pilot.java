package org.cap.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
/*import javax.validation.constraints.Future;
import javax.validation.constraints.Past;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;
*/
@Entity
public class Pilot{
	@Id
private int pilotId;
//@NotEmpty(message="*please enter firstname")
private String firstName;

//@NotEmpty(message="*please enter lastname")
private String lastName;

//@Past(message="please enter a past date")
private Date dateOfBirth;

//@Future(message="*please enter a future date")
private Date dateOfJoining;
private Boolean isCertified;
//@Range(min=100, max=10000, message="Range should be between 100 to 10k")
private double salary;

//@Email(message="Please enter a valid mail ID")
private String email;

public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public Pilot() {
	
}

public int getPilotId() {
	return pilotId;
}
public void setPilotId(int pilotId) {
	this.pilotId = pilotId;
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}

public Pilot(int pilotId, String firstName, String lastName, Date dateOfBirth, Date dateOfJoining, Boolean isCertified,
		double salary, String email) {
	super();
	this.pilotId = pilotId;
	this.firstName = firstName;
	this.lastName = lastName;
	this.dateOfBirth = dateOfBirth;
	this.dateOfJoining = dateOfJoining;
	this.isCertified = isCertified;
	this.salary = salary;
	this.email = email;
}
@Override
public String toString() {
	return "Pilot [pilotId=" + pilotId + ", firstName=" + firstName + ", lastName=" + lastName + ", dateOfBirth="
			+ dateOfBirth + ", dateOfJoining=" + dateOfJoining + ", isCertified=" + isCertified + ", salary=" + salary
			+ ", email=" + email + "]";
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public Date getDateOfBirth() {
	return dateOfBirth;
}
public void setDateOfBirth(Date dateOfBirth) {
	this.dateOfBirth = dateOfBirth;
}
public Date getDateOfJoining() {
	return dateOfJoining;
}
public void setDateOfJoining(Date dateOfJoining) {
	this.dateOfJoining = dateOfJoining;
}
           
public Boolean getIsCertified() {
	return isCertified;
}
public void setIsCertified(Boolean isCertified) {
	this.isCertified = isCertified;
}
public double getSalary() {
	return salary;
}
public void setSalary(double salary) {
	this.salary = salary;
}
}
