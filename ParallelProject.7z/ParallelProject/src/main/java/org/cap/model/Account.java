package org.cap.model;

import java.util.Date;

public class Account {
private long accountId;
private long accountNo;
private String accountType;
private double openingBalance;
private Date currentDate;
private long customerId;
private String status;
public long getAccountId() {
	return accountId;
}
public void setAccountId(long accountId) {
	this.accountId = accountId;
}
public long getAccountNo() {
	return accountNo;
}
public void setAccountNo(long accountNo) {
	this.accountNo = accountNo;
}
public String getAccountType() {
	return accountType;
}
public void setAccountType(String accountType) {
	this.accountType = accountType;
}
public double getOpeningBalance() {
	return openingBalance;
}
public void setOpeningBalance(double openingBalance) {
	this.openingBalance = openingBalance;
}
public Date getCurrentDate() {
	return currentDate;
}
public void setCurrentDate(Date currentDate) {
	this.currentDate = currentDate;
}
public long getCustomerId() {
	return customerId;
}
public void setCustomerId(long customerId) {
	this.customerId = customerId;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
public Account(long accountId, long accountNo, String accountType, double openingBalance, Date currentDate,
		long customerId, String status) {
	super();
	this.accountId = accountId;
	this.accountNo = accountNo;
	this.accountType = accountType;
	this.openingBalance = openingBalance;
	this.currentDate = currentDate;
	this.customerId = customerId;
	this.status = status;
}
public Account() {
	super();
}
@Override
public String toString() {
	return "Account [accountId=" + accountId + ", accountNo=" + accountNo + ", accountType=" + accountType
			+ ", openingBalance=" + openingBalance + ", currentDate=" + currentDate + ", customerId=" + customerId
			+ ", status=" + status + "]";
}


}
