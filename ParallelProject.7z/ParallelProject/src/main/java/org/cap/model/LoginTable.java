package org.cap.model;

import java.util.Date;

public class LoginTable {
private long customerId;
private String password;
private String status;
private Date loginDate;
private String firstName;
private String lastName;
private String email;
private long mobile;
public long getCustomerId() {
	return customerId;
}
public void setCustomerId(long customerId) {
	this.customerId = customerId;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
public Date getLoginDate() {
	return loginDate;
}
public void setLoginDate(Date loginDate) {
	this.loginDate = loginDate;
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public long getMobile() {
	return mobile;
}
public void setMobile(long mobile) {
	this.mobile = mobile;
}
public LoginTable(long customerId, String password, String status, Date loginDate, String firstName, String lastName,
		String email, long mobile) {
	super();
	this.customerId = customerId;
	this.password = password;
	this.status = status;
	this.loginDate = loginDate;
	this.firstName = firstName;
	this.lastName = lastName;
	this.email = email;
	this.mobile = mobile;
}
public LoginTable() {
	super();
}
@Override
public String toString() {
	return "LoginTable [customerId=" + customerId + ", password=" + password + ", status=" + status + ", loginDate=" + loginDate
			+ ", firstName=" + firstName + ", lastName=" + lastName + ", email=" + email + ", mobile=" + mobile + "]";
}


}
